-- AlterTable
ALTER TABLE `shoppingitem` MODIFY `checked` BOOLEAN NOT NULL DEFAULT false;
